from typing import Optional
from config import ALLOWED_PIPELINE_STAGES
import pandas as pd
from config import MAX_RESULTS
from dependencies import logger

def generate_mermaid_bar_chart(df: pd.DataFrame, x_col: str, y_col: str, title: str = "PnL Trend") -> str:
    """Converts a pandas DataFrame into a clean Mermaid xychart line chart."""
    if df.empty or x_col not in df.columns or y_col not in df.columns:
        return ""
        
    # Standardize string formatting without raw HTML breaks that break Mermaid parser
    x_vals = [str(val).replace('"', '') for val in df[x_col].tolist()]
    y_vals = [float(val) for val in df[y_col].tolist()]
    
    x_axis_str = ", ".join(f'"{x}"' for x in x_vals)
    y_axis_str = ", ".join(str(y) for y in y_vals)
    
    return f"""```mermaid
%%{{init: 
{{
    "theme": "base",
        "themeVariables": {{
                "backgroundColor": "#FFFFFF",
                "xyChart": {{
                    'width': 900,
                    'height': 500,
                    'xAxis': {{
                        'labelRotation': 45,
                        'labelFontSize': 11
                    }}
                }}
                "backgroundColor": "#F8FAFC",
                "titleColor": "#0F172A",
                "xAxisLabelColor": "#475569",
                "xAxisTitleColor": "#0F172A",
                "xAxisLineColor": "#CBD5E1",
                "yAxisLabelColor": "#475569",
                "yAxisTitleColor": "#0F172A",
                "yAxisLineColor": "#CBD5E1",
                "plotColorPalette": "#2563EB, #7C3AED, #059669"
                }}
        }}
    }}
}}%%
xychart-beta
    title "{title}"
    x-axis [{x_axis_str}]
    y-axis "{y_col}"
    line [{y_axis_str}]
```"""

def validate_pipeline_stages(pipeline: list) -> Optional[str]:
    """Returns an error message if the pipeline contains a disallowed stage, else None."""
    if not isinstance(pipeline, list):
        return "Pipeline must be a JSON array of stage objects."
    for stage in pipeline:
        if not isinstance(stage, dict) or len(stage) != 1:
            return f"Malformed pipeline stage: {stage}"
        stage_name = next(iter(stage.keys()))
        if stage_name not in ALLOWED_PIPELINE_STAGES:
            return f"Disallowed pipeline stage: '{stage_name}'."
    return None

def format_results(results: list):
        result_count = len(results)
        if result_count > MAX_RESULTS:
            return (
                f"Do NOT run any query again."
                f"Query returned {result_count} results, which exceeds the maximum limit of {MAX_RESULTS}. "
                "There are too many results. Please refine your query by getting sumn over the group."
            )
        elif result_count == 0:
            return (
                "No matching PnL records were found for the specified criteria."
            )

        if not results:
            logger.info("Query returned no matching records.")
            return "No matching PnL records were found for the specified criteria."
            
        df = pd.DataFrame(results)

        # # Separate PnL_cols and non_PnL_cols
        PnL_cols = [col for col in df.columns if 'pnl' in col.lower()]
        non_PnL_cols = [col for col in df.columns if col not in PnL_cols]
        date_col = [col for col in df.columns if 'day' in col.lower() or 'date' in col.lower()]
        # logger.info(f"{PnL_cols=}, {non_PnL_cols=}, {date_col=}")
        if date_col:
            non_PnL_cols.remove(date_col[0]) 
            non_PnL_cols = [date_col[0]] + non_PnL_cols  
            df[date_col[0]] = df[date_col[0]].dt.strftime('%Y-%m-%d')
            # logger.info(f"{date_col=}")
        # # keep PnL_cols at the end
        df = df[list(non_PnL_cols) + list(PnL_cols)]
        
        markdown_table = df.to_markdown(index=False)
    
        # Optionally generate a graph if numeric and string columns are present
        mermaid_chart = ""
        cols = df.columns.tolist()
        if len(df) <=50 and len(cols) >= 2 and pd.api.types.is_numeric_dtype(df[cols[-1]]):
            mermaid_chart = generate_mermaid_bar_chart(df, x_col=cols[0], y_col=cols[-1])

        if mermaid_chart:
            mongo_results = f"{markdown_table}\n\n**Trend:**\n\n{mermaid_chart}\n\n"
        else:
            mongo_results = f"{markdown_table}"
        return mongo_results

