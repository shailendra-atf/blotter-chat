# mcp_server.py
import json, os
from typing import List, Dict, Any
from fastmcp import FastMCP
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import StrOutputParser
import dependencies

# Initialize FastMCP Server
mcp = FastMCP("MongoDB-Orchestrator-Tools")

# Shared Gemini LLM instance for server-side generation
llm_chain = ChatGoogleGenerativeAI(model="gemini-3.1-flash-lite", temperature=0) | StrOutputParser()

@mcp.tool()
async def generate_mongodb_query(doc_context: str, user_prompt: str) -> str:
    """
    MCP Tool: Generates a MongoDB query based on retrieved doc context and user request.
    """
    prompt = f"""
    Based on the context and user request, generate a valid MongoDB JSON query.
    Context: {doc_context}
    User Request: {user_prompt}
    Return ONLY raw JSON/MQL code without markdown code blocks.
    """
    raw_query = await llm_chain.ainvoke([HumanMessage(content=prompt)])
    return raw_query.strip()

@mcp.tool()
async def execute_mongodb_query(query: str) -> Dict[str, Any]:
    """
    MCP Tool: Executes a generated MongoDB query against the database.
    """
    try:
        # --- Real PyMongo Execution Example ---
        # client = MongoClient("mongodb://localhost:27017/")
        # db = client["your_database"]
        # query_dict = json.loads(query)
        # results = list(db["your_collection"].find(query_dict))
        
        # --- Simulated Execution Result ---
        results = [{"_id": "doc_101", "status": "active", "query_run": query}]
        
        return {
            "query": query,
            "status": "success",
            "data": results
        }
    except Exception as e:
        return {
            "query": query,
            "status": "error",
            "error_message": str(e)
        }

@mcp.tool()
async def supervisor_aggregate(user_prompt: str, query_results: List[Dict[str, Any]]) -> str:
    """
    MCP Tool: Synthesizes final user response from all parallel execution results.
    """
    prompt = f"""
    Synthesize a clear, concise final response for the user prompt based on all executed MongoDB results.
    User Request: {user_prompt}
    Execution Results: {json.dumps(query_results, indent=2)}
    """
    final_summary = await llm_chain.ainvoke([HumanMessage(content=prompt)])
    return final_summary.strip()

if __name__ == "__main__":
    # Runs standard IO server for client connections
    mcp.run(transport="stdio")