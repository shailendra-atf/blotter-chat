# orchestrator.py
import os
import asyncio
import operator
from typing import Annotated, List, Dict, Any
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from langchain_mcp_adapters.client import MultiServerMCPClient
from utils import startup_db_client, get_unique_names_from_database
from rag_ingestion import initialize_chromadb
# Set your API Key
# os.environ["GEMINI_API_KEY"] = "your-api-key"

# ==========================================
# 1. State Schema
# ==========================================
class AgentState(TypedDict):
    user_prompt: str
    retrieved_docs: List[str]
    # Reducers using operator.add to safely accumulate parallel outputs
    mongodb_queries: Annotated[List[str], operator.add]
    query_results: Annotated[List[Dict[str, Any]], operator.add]
    final_response: str

class TaskState(TypedDict):
    doc: str
    user_prompt: str

async def _bootstrap_runtime():
    db = await startup_db_client()
    chroma_collection = initialize_chromadb()
    unique_names = ""#await get_unique_names_from_database(db) if db is not None else {}
    return db, chroma_collection, unique_names


db, chroma_collection, UNIQUE_NAMES_DICT = asyncio.run(_bootstrap_runtime())

# ==========================================
# 2. Main Orchestrator Setup
# ==========================================
async def build_orchestrator():
    # Path to the MCP tool server script
    server_path = os.path.abspath("mcp_server.py")
    
    # Initialize MultiServerMCPClient to discover tools
    mcp_client = MultiServerMCPClient({
        "mongo_tools": {
            "command": "python",
            "args": [server_path],
            "transport": "stdio"
        }
    })

    # Load MCP Tools directly into LangChain structured tools lookup table
    tools_list = await mcp_client.get_tools()
    mcp_tools = {tool.name: tool for tool in tools_list}
    
    # Tool Handles
    mcp_gen_query = mcp_tools["generate_mongodb_query"]
    mcp_exec_query = mcp_tools["execute_mongodb_query"]
    mcp_aggregate = mcp_tools["supervisor_aggregate"]

    # ==========================================
    # 3. Graph Nodes Calling MCP Tools
    # ==========================================

    async def rag_worker(state: AgentState):
        """Simulated RAG retriever node."""
        simulated_docs = [
            "Collection: 'users'. Filter active users where age > 25.",
            "Collection: 'orders'. Filter completed orders where total_amount > 100."
        ]
        results = chroma_collection.query(query_texts=[state.get("user_prompt")], n_results=min(2, chroma_collection.count()))
        if not results or not results["metadatas"][0]:
            return "No matching database schemas located for this intent."

        return {"retrieved_docs": simulated_docs}

    def supervisor_fanout(state: AgentState):
        """Supervisor router: Dynamic parallel fan-out using Send()."""
        fanout_branches = []
        for doc in state["retrieved_docs"]:
            fanout_branches.append(
                Send("generate_mongodb_query_node", {
                    "doc": doc, 
                    "user_prompt": state["user_prompt"]
                })
            )
        return fanout_branches

    async def generate_mongodb_query_node(state: TaskState):
        """Node executing MCP Tool: generate_mongodb_query"""
        doc = state["doc"]
        target_resource = doc.split("'", 2)[1] if "'" in doc else ""
        result = await mcp_gen_query.ainvoke({
            "db_type": "MongoDB",
            "target_resource": target_resource,
            "schema_info": doc,
            "user_intent": state["user_prompt"],
        })
        return {"mongodb_queries": [result]}

    async def execute_mongodb_query_node(state: AgentState):
        """Node executing MCP Tool: execute_mongodb_query across parallel tasks"""
        # Execute query for each generated branch query
        results = []
        for q in state["mongodb_queries"]:
            res = await mcp_exec_query.ainvoke({"query": q})
            results.append(res)
        return {"query_results": results}

    async def supervisor_aggregate_node(state: AgentState):
        """Node executing MCP Tool: supervisor_aggregate"""
        result = await mcp_aggregate.ainvoke({
            "user_prompt": state["user_prompt"],
            "query_results": state["query_results"]
        })
        return {"final_response": result}

    # ==========================================
    # 4. Graph Construction
    # ==========================================
    builder = StateGraph(AgentState)

    builder.add_node("rag_worker", rag_worker)
    builder.add_node("generate_mongodb_query_node", generate_mongodb_query_node)
    builder.add_node("execute_mongodb_query_node", execute_mongodb_query_node)
    builder.add_node("supervisor_aggregate_node", supervisor_aggregate_node)

    # Connections
    builder.add_edge(START, "rag_worker")

    # Dynamic Fan-Out from RAG results
    builder.add_conditional_edges(
        "rag_worker",
        supervisor_fanout,
        ["generate_mongodb_query_node"]
    )

    # Execution and Aggregation (Fan-In)
    builder.add_edge("generate_mongodb_query_node", "execute_mongodb_query_node")
    builder.add_edge("execute_mongodb_query_node", "supervisor_aggregate_node")
    builder.add_edge("supervisor_aggregate_node", END)

    return builder.compile()


# ==========================================
# 5. Run Graph
# ==========================================
async def main():
    graph = await build_orchestrator()
    
    inputs = {
        "user_prompt": "can u tell me the MTDPnl for Trader Rajesh Mahadevan for Month March 2026 for the last business day of the month"
    }
    await graph.ainvoke(inputs)

    # async for step in graph.astream(inputs):
    #     for node_name, state_update in step.items():
    #         print(f"--- Completed Node: {node_name} ---")
    #         print(state_update)
    #         print("\n")

if __name__ == "__main__":
    asyncio.run(main())