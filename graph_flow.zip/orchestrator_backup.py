import asyncio
import os
import sys
# from typing import Annotated, List, TypedDict
from langchain_core.prompts import ChatPromptTemplate
from dotenv import load_dotenv
load_dotenv(override=True)
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
# import sys, io
# if sys.platform == "win32":
#     sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
#     sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
from pathlib import Path


# Import MCP Client Utilities
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.sse import sse_client
from mcp.shared.exceptions import MCPError

from config import MODEL_ID
from models import RouterDecision, WorkerState, MasterState
from utils import execute_mongo_query, llm

import dependencies # this statement is required
from dependencies import logger


MCP_SERVER_SCRIPT = str((Path(__file__).parent / "hybrid_mcp_server.py").resolve())
PYTHONPATH = str((Path(__file__).parent / ".venv312/Scripts/python").resolve())

# logger.info(PYTHONPATH, MCP_SERVER_SCRIPT)
# Connect configuration parameter for your Hybrid MCP server python script
mcp_server_params = StdioServerParameters(
    command=PYTHONPATH,
    args=[MCP_SERVER_SCRIPT]
)


structured_router = llm.with_structured_output(RouterDecision)

# ==========================================
# 2. THE SUPERVISOR NODE (AGENT ROUTER)
# ==========================================

from typing import List, Dict, Any
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field


# ==========================================
# 2. UPDATED AGENT ROUTER NODE
# ==========================================
async def agent_router_node(state: MasterState):
    """
    Coordinates the multi-hop loop by transitioning systematically from RAG table identification, 
    to LLM syntax generation, to multi-database execution, and finally to report generation.
    """
    logger.info(f"\n--- [Hop {state['loop_count']}] Supervisor Evaluating Graph State ---")
    
    router_prompt = ChatPromptTemplate.from_messages([
        ("system", (
            "You are a master database orchestrator supervising an agent swarm.\n"
            "Your objective is to answer the user query by routing through discovery, code translation, and execution.\n\n"
            "========= STEP 1: SCHEMAS DISCOVERED VIA RAG =========\n"
            "{schema_registry}\n\n"
            "========= STEP 2: COMPILED QUERY SYNTAX GENERATED =========\n"
            "{compiled_queries}\n\n"
            "========= STEP 3: LIVE RECORDE RETRIEVED FROM DBs =========\n"
            "{context}\n\n"
            "ROUTING RULES:\n"
            "1. If you don't know the exact target resource names or design structures, set decision='DISCOVER_SCHEMA'.\n"
            # "2. If you see schemas in 'STEP 1' but have not yet compiled them into strict database strings, set decision='GENERATE_QUERY'. Populated 'queries_to_generate'.\n"
            "3. If you see compiled query strings in 'STEP 2' that haven't run, set decision='EXECUTE_QUERY'. Populate 'queries_to_execute'.\n"
            "4. If 'STEP 3' contains enough data context to answer the user query completely, set decision='FINAL_ANSWER'.\n\n"
            "Do not skip steps. Ensure your database queries precisely use the exact strings found in Step 1."
        )),
        ("human", "{question}")
    ])
    
    structured_router = llm.with_structured_output(RouterDecision)
    
    # Extract historical tracking strings from state
    formatted_schemas = "\n".join(state.get("schema_registry", [])) if state.get("schema_registry") else "No table schemas discovered yet."
    # To support this, add 'compiled_queries' as an Annotated[List[str], add] key in your MasterState dictionary definition
    formatted_queries = "\n".join(state.get("compiled_queries", [])) if state.get("compiled_queries") else "No query syntax generated yet."
    formatted_context = "\n".join(state.get("context", [])) if state.get("context") else "No live database records retrieved yet."
    
    response = await (router_prompt | structured_router).ainvoke({
        "question": state["question"],
        "schema_registry": formatted_schemas,
        "compiled_queries": formatted_queries,
        "context": formatted_context
    })
    
    action = response.decision
    if state["loop_count"] >= 4:  # Expanded threshold to account for extra progressive generation hop
        logger.info("⚠️ Safety Threshold: Enforcing compilation exit to prevent loop inflation.")
        action = "FINAL_ANSWER"
        
    logger.info(f"🤖 Supervisor Decision: {action} | Reasoning: {response.reasoning}")
    
    # Repackage dynamic tasks arrays for the conditional fan-out mapping step
    packaged_tasks = []
    if action == "DISCOVER_SCHEMA":
        for intent in response.plain_text_intents:
            packaged_tasks.append({"task_type": "DISCOVER_SCHEMA", "payload": {"intent": intent}})
            logger.info(f"   ↳ Scheduled dynamic RAG Discovery intent: '{intent}'")

    elif action == "GENERATE_QUERY":
        for gen_job in response.queries_to_generate:
            packaged_tasks.append({"task_type": "GENERATE_QUERY", "payload": gen_job})
            logger.info(f"   ↳ Scheduled dynamic query translation for {gen_job.get('db_type')}.{gen_job.get('target_resource')}")

    elif action == "EXECUTE_QUERY":
        for exec_job in response.queries_to_execute:
            packaged_tasks.append({"task_type": "EXECUTE_QUERY", "payload": exec_job})
            logger.info(f"   ↳ Scheduled live database query execution block on {exec_job.get('db_type')}.{exec_job.get('target_resource')}")

    return {
        "next_action": action,
        "tasks_to_run": packaged_tasks,
        "loop_count": state["loop_count"] + 1
    }

# ==========================================
# 3. DYNAMIC PARALLEL MCP WORKER NODE
# ==========================================
def _extract_mcp_text(result) -> str:
    """Normalize FastMCP content payloads into a plain string."""
    content = getattr(result, "content", None)
    if isinstance(content, list):
        if not content:
            return ""
        first = content[0]
        if hasattr(first, "text"):
            return first.text
        if isinstance(first, dict):
            return first.get("text", str(first))
        return str(first)
    if hasattr(content, "text"):
        return content.text
    if isinstance(content, str):
        return content
    return str(content)

async def dynamic_mcp_worker(state: WorkerState):
    """Parallel runtime worker. Communicates dynamically via standard I/O streams with the MCP Server."""
    task_type = state.get("task_type")
    payload = state.get("payload") or {}

    try:
        async with stdio_client(mcp_server_params) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                # Sub-Track A: Use RAG to pinpoint exact tables across hundreds of candidates
                if task_type == "DISCOVER_SCHEMA":
                    intent = payload.get("intent")
                    if not intent:
                        logger.warning(f"Skipping DISCOVER_SCHEMA task with empty payload: {payload}")
                        return {}
                    logger.info(f"  └─► [Parallel Worker] Executing RAG Schema Lookup for: '{intent}'")
                    mcp_res = await session.call_tool("find_relevant_tables", arguments={"user_intent": intent})
                    return {"schema_registry": [_extract_mcp_text(mcp_res)]}

                elif task_type == "GENERATE_QUERY":
                    db_type = payload.get("db_type")
                    target = payload.get("target_resource")
                    schema_info = payload.get("schema_info")
                    user_intent = payload.get("user_intent")

                    if not db_type or not target or not schema_info or not user_intent:
                        logger.warning(f"Skipping malformed GENERATE_QUERY payload: {payload}")
                        return {}

                    logger.info(f"  └─► [Parallel Worker] Calling MCP Query Generator for {db_type}.{target}")
                    mcp_res = await session.call_tool(
                        "generate_db_query",
                        arguments={
                            "db_type": db_type,
                            "target_resource": target,
                            "schema_info": schema_info,
                            "user_intent": user_intent
                        }
                    )
                    generated_string = _extract_mcp_text(mcp_res)
                    return {
                        "compiled_queries": [f"Compiled {db_type} Syntax for {target}: {generated_string}"]
                    }

                # Sub-Track C: Execute compiled queries natively against SQL or MongoDB targets
                elif task_type == "EXECUTE_QUERY":
                    db_type = payload.get("db_type")
                    target = payload.get("target_resource")
                    query_str = payload.get("query_string")

                    if query_str is None:
                        schema_info = payload.get("schema_info")
                        user_intent = payload.get("user_intent")
                        if not db_type or not target or not schema_info or not user_intent:
                            logger.warning(f"Skipping malformed EXECUTE_QUERY payload: {payload}")
                            return {}
                        logger.info(f"  └─► [Parallel Worker] Generating then executing {db_type} Query on '{target}'")
                        generated = await session.call_tool(
                            "generate_db_query",
                            arguments={
                                "db_type": db_type,
                                "target_resource": target,
                                "schema_info": schema_info,
                                "user_intent": user_intent
                            }
                        )
                        query_str = _extract_mcp_text(generated)

                    if not db_type or not target or not query_str:
                        logger.warning(f"Skipping incomplete EXECUTE_QUERY payload: {payload}")
                        return {}

                    logger.info(f"  └─► [Parallel Worker] Executing live {db_type} Query on '{target}'")
                    mcp_res = await session.call_tool(
                        "execute_hybrid_query",
                        arguments={"db_type": db_type, "target_resource": target, "query_string": query_str}
                    )
                    result_text = _extract_mcp_text(mcp_res)
                    return {"context": [f"Result from {db_type}.{target}: {result_text}"]}
    except MCPError as e:
        logger.info(f"MCP Communication Error: {e}")
    return {}

# ==========================================
# 4. FINAL COMPILATION NODE
# ==========================================
async def generate_final_report_node(state: MasterState):
    logger.info("\n--- Synthesizing Final Hybrid Data Report ---")
    gen_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an analytics assistant. Build a clear summary using data fields pulled across systems.\n\nData Context:\n{context}"),
        ("human", "{question}")
    ])
    
    res = await (gen_prompt | llm).ainvoke({
        "question": state["question"],
        "context": "\n".join(state["context"])
    })
    logger.info(f"\n✨ [Final Response]:\n{res.content}")
    return {}

# ==========================================
# 5. DYNAMIC MAP-REDUCE EDGE LOGIC
# ==========================================
def map_dynamic_jobs(state: MasterState):
    """Reads supervisor generated task payloads array and splits them into distinct parallel node executions."""
    tasks = state.get("tasks_to_run", [])
    if state["next_action"] == "DISCOVER_SCHEMA":
        return "supervisor"
    if state["next_action"] == "FINAL_ANSWER" or not tasks:
        return "generator"
        
    # Standard Send API fans-out dynamically based on calculated list sizes
    return [Send("mcp_worker", t) for t in tasks]

# ==========================================
# 6. CONNECTING THE WORKFLOW GRAPH
# ==========================================
workflow = StateGraph(MasterState)

workflow.add_node("supervisor", agent_router_node)
workflow.add_node("mcp_worker", dynamic_mcp_worker)
workflow.add_node("generator", generate_final_report_node)
workflow.add_edge(START, "supervisor")

# Conditional fan-out mapping using Send architecture
workflow.add_conditional_edges(
    "supervisor",
    map_dynamic_jobs,
    {
        "mcp_worker": "mcp_worker", # for finding relevant table, preparing a query and executing it.
        "generator": "generator"
    }
)

# Parallel processes fan-in block: synchronizes results and routes execution directly back to supervisor loop
workflow.add_edge("mcp_worker", "supervisor")
workflow.add_edge("generator", END)

langgraph_app = workflow.compile()

def save_workflow_image():
    png_bytes = langgraph_app.get_graph().draw_mermaid_png()

    # Save bytes to a file
    with open("graph_flow.png", "wb") as f:
        f.write(png_bytes)


async def run_pipeline():
    # await get_unique_names_from_database(db)
    # Example cross-database query request requiring sequential schema-discovery and live data extraction
    cross_db_query = "can u tell me the MTDPnl for Trader Rajesh Mahadevan for Month March 2026 for the last business day of the month"

    initial_state = {
        "question": cross_db_query,
        "context": [],
        "schema_registry": [],
        "loop_count": 0,
        "next_action": "",
        "tasks_to_run": []
    }

    await langgraph_app.ainvoke(initial_state)


if __name__ == "__main__":
    save_workflow_image()
    asyncio.run(run_pipeline())
